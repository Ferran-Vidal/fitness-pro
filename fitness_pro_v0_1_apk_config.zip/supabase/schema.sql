-- Fitness Pro: initial private multi-user schema.
-- Run in Supabase SQL Editor after creating a project.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  height_cm numeric(5,1),
  weight_kg numeric(5,1),
  created_at timestamptz not null default now()
);

create table if not exists public.exercises (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  muscle_groups text[] not null default '{}',
  equipment text,
  instructions text,
  image_url text,
  source text default 'custom',
  created_at timestamptz not null default now()
);

create table if not exists public.routines (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  weekday smallint check (weekday between 0 and 6),
  created_at timestamptz not null default now()
);

create table if not exists public.routine_exercises (
  id uuid primary key default gen_random_uuid(),
  routine_id uuid not null references public.routines(id) on delete cascade,
  exercise_id uuid not null references public.exercises(id),
  position integer not null default 0,
  target_sets integer not null default 3,
  target_reps text not null default '8-12',
  rest_seconds integer not null default 90,
  target_weight_kg numeric(6,2)
);

create table if not exists public.workout_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  routine_id uuid references public.routines(id) on delete set null,
  started_at timestamptz not null default now(),
  finished_at timestamptz,
  notes text
);

create table if not exists public.set_logs (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.workout_sessions(id) on delete cascade,
  routine_exercise_id uuid references public.routine_exercises(id) on delete set null,
  exercise_id uuid not null references public.exercises(id),
  set_number integer not null,
  weight_kg numeric(6,2),
  reps integer,
  rir numeric(3,1),
  completed boolean not null default false,
  logged_at timestamptz not null default now()
);

create table if not exists public.muscle_load_estimates (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  session_id uuid references public.workout_sessions(id) on delete cascade,
  muscle_group text not null,
  estimated_load numeric(5,2) not null check (estimated_load between 0 and 100),
  calculated_at timestamptz not null default now()
);

create table if not exists public.invitations (
  id uuid primary key default gen_random_uuid(),
  invited_email text not null,
  token_hash text not null unique,
  created_by uuid not null references auth.users(id),
  expires_at timestamptz not null,
  accepted_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.routines enable row level security;
alter table public.routine_exercises enable row level security;
alter table public.workout_sessions enable row level security;
alter table public.set_logs enable row level security;
alter table public.muscle_load_estimates enable row level security;
alter table public.invitations enable row level security;
alter table public.exercises enable row level security;

-- Users can access only their own profile and training records.
create policy "profile own row" on public.profiles for all
using (auth.uid() = id) with check (auth.uid() = id);

create policy "routines own rows" on public.routines for all
using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "routine exercises through owned routine" on public.routine_exercises for all
using (exists (select 1 from public.routines r where r.id = routine_id and r.user_id = auth.uid()))
with check (exists (select 1 from public.routines r where r.id = routine_id and r.user_id = auth.uid()));

create policy "sessions own rows" on public.workout_sessions for all
using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "set logs own sessions" on public.set_logs for all
using (exists (select 1 from public.workout_sessions s where s.id = session_id and s.user_id = auth.uid()))
with check (exists (select 1 from public.workout_sessions s where s.id = session_id and s.user_id = auth.uid()));

create policy "muscle estimates own rows" on public.muscle_load_estimates for all
using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Exercise catalogue is readable by signed-in users; only service/admin process seeds it.
create policy "signed in read exercises" on public.exercises for select
using (auth.role() = 'authenticated');

-- Invitation table has no client policies: invitation creation/acceptance must be
-- implemented with a trusted server/Edge Function using the service role.
