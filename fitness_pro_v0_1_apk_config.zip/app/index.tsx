import { useState } from "react";
import { View, Text, ScrollView, Pressable, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";

const GREEN = "#42D982";
const MUTED = "#8D9A92";
const panels = ["Inicio", "Rutinas", "Entrenar", "Progreso", "Fatiga", "Perfil"];
const icons: Record<string, keyof typeof Ionicons.glyphMap> = {
  Inicio: "home-outline", Rutinas: "calendar-outline", Entrenar: "barbell-outline",
  Progreso: "stats-chart-outline", Fatiga: "body-outline", Perfil: "person-outline"
};

function Card({ children }: { children: React.ReactNode }) {
  return <View style={s.card}>{children}</View>;
}
function Metric({ label, value, unit }: { label: string; value: string; unit?: string }) {
  return <View style={{ flex: 1 }}>
    <Text style={s.muted}>{label}</Text>
    <Text style={s.metric}>{value}<Text style={s.unit}> {unit}</Text></Text>
  </View>;
}

export default function Home() {
  const [tab, setTab] = useState("Inicio");
  const [done, setDone] = useState([true, true, false, false]);
  const toggle = (i: number) => setDone(old => old.map((v, n) => n === i ? !v : v));
  return <View style={s.screen}>
    <View style={s.top}>
      <View>
        <Text style={s.eyebrow}>TU ENTRENAMIENTO, BAJO CONTROL</Text>
        <Text style={s.brand}>FITNESS <Text style={{ color: GREEN }}>PRO</Text></Text>
      </View>
      <Pressable style={s.avatar} onPress={() => setTab("Perfil")}><Ionicons name="person" size={20} color={GREEN}/></Pressable>
    </View>
    <ScrollView contentContainerStyle={{ paddingBottom: 110 }}>
      {tab === "Inicio" && <>
        <Text style={s.greeting}>¡Vamos a entrenar!</Text>
        <Text style={s.muted}>Aquí tienes el resumen de tu actividad.</Text>
        <View style={s.row}>
          <Card><Metric label="Sesiones esta semana" value="3" unit="/ 5"/></Card>
          <Card><Metric label="Tiempo entrenado" value="2 h 40" unit="min"/></Card>
        </View>
        <Card>
          <View style={s.between}><Text style={s.cardTitle}>Próximo entrenamiento</Text><Text style={s.tag}>HOY</Text></View>
          <Text style={s.workout}>Pecho · Hombro · Tríceps</Text>
          <Text style={s.muted}>6 ejercicios · Aproximadamente 60 min</Text>
          <Pressable style={s.primary} onPress={() => setTab("Entrenar")}><Text style={s.primaryText}>Comenzar entrenamiento</Text><Ionicons name="arrow-forward" color="#06110A" size={18}/></Pressable>
        </Card>
        <Card>
          <Text style={s.cardTitle}>Tu semana</Text>
          <View style={s.week}>{["L","M","X","J","V","S","D"].map((d,i)=><View key={d} style={s.day}>
            <View style={[s.dot, [0,2,4].includes(i) && s.dotActive]}><Text style={[s.dayLetter,[0,2,4].includes(i)&&{color:"#06110A"}]}>{d}</Text></View>
            <Text style={s.dayLabel}>{[0,2,4].includes(i)?"Hecho":"—"}</Text>
          </View>)}</View>
        </Card>
        <Card>
          <View style={s.between}><Text style={s.cardTitle}>Carga muscular estimada</Text><Text style={s.tag}>DEMO</Text></View>
          <Text style={s.muted}>Ejemplo visual; se calculará con tus series reales.</Text>
          {["Pectoral","Tríceps","Deltoides"].map((m,i)=><View key={m} style={{ marginTop: 14 }}>
            <View style={s.between}><Text style={s.body}>{m}</Text><Text style={s.body}>{[68,54,42][i]}%</Text></View>
            <View style={s.track}><View style={[s.fill,{width:`${[68,54,42][i]}%`}]} /></View>
          </View>)}
          <Pressable onPress={() => setTab("Fatiga")}><Text style={s.link}>Ver mapa muscular →</Text></Pressable>
        </Card>
      </>}
      {tab === "Rutinas" && <><Text style={s.greeting}>Tus rutinas</Text><Text style={s.muted}>Organiza tus días y ejercicios.</Text>{["Lunes · Pecho, hombro y tríceps","Martes · Espalda y bíceps","Jueves · Pierna","Viernes · Torso"].map((x,i)=><Card key={x}><Text style={s.cardTitle}>{x}</Text><Text style={s.muted}>{[6,5,7,6][i]} ejercicios · Rutina editable</Text></Card>)}</>}
      {tab === "Entrenar" && <><Text style={s.greeting}>Entrenamiento activo</Text><Text style={s.muted}>Lunes · Pecho, hombro y tríceps</Text>{["Press banca · 4 × 8","Press inclinado · 3 × 10","Aperturas · 3 × 12","Press militar · 3 × 8"].map((x,i)=><Pressable key={x} onPress={()=>toggle(i)}><Card><View style={s.between}><View><Text style={s.cardTitle}>{x}</Text><Text style={s.muted}>Objetivo de hoy · registra tus series</Text></View><Ionicons name={done[i]?"checkmark-circle":"ellipse-outline"} color={done[i]?GREEN:MUTED} size={25}/></View></Card></Pressable>)}</>}
      {tab === "Progreso" && <><Text style={s.greeting}>Progreso</Text><Text style={s.muted}>Historial, marcas y evolución.</Text><Card><Text style={s.cardTitle}>Historial semanal</Text><Text style={s.muted}>Aquí se mostrará la tabla de peso y repeticiones previstas frente a las realizadas.</Text></Card><Card><Text style={s.cardTitle}>Récords personales</Text><Text style={s.muted}>Tus mejores marcas por ejercicio aparecerán aquí cuando registres entrenamientos.</Text></Card></>}
      {tab === "Fatiga" && <><Text style={s.greeting}>Fatiga muscular</Text><Text style={s.muted}>Mapa interactivo en desarrollo.</Text><Card><Text style={s.cardTitle}>Vista corporal</Text><Text style={s.muted}>La versión completa incluirá vistas frontal y posterior con músculos seleccionables. Los porcentajes serán estimaciones de carga reciente, no mediciones fisiológicas.</Text></Card>{["Pectoral","Deltoides","Bíceps","Tríceps","Dorsales","Abdominales","Cuádriceps","Isquiotibiales","Glúteos","Gemelos"].map(x=><Card key={x}><View style={s.between}><Text style={s.body}>{x}</Text><Text style={s.muted}>Sin datos todavía</Text></View></Card>)}</>}
      {tab === "Perfil" && <><Text style={s.greeting}>Tu perfil</Text><Text style={s.muted}>Cuenta personal y configuración.</Text><Card><Text style={s.cardTitle}>Datos personales</Text><Text style={s.muted}>Nombre, altura y peso se podrán editar desde aquí.</Text></Card><Card><Text style={s.cardTitle}>Privacidad</Text><Text style={s.muted}>Cada cuenta tendrá sus propios datos privados. El administrador solo gestionará invitaciones y no podrá consultar entrenamientos ajenos.</Text></Card></>}
    </ScrollView>
    <View style={s.nav}>{panels.map(p=><Pressable key={p} onPress={()=>setTab(p)} style={s.navItem}>
      <Ionicons name={icons[p]} size={21} color={tab===p?GREEN:MUTED}/>
      <Text style={[s.navText,tab===p&&{color:GREEN}]}>{p}</Text>
    </Pressable>)}</View>
  </View>;
}
const s = StyleSheet.create({
  screen:{flex:1,backgroundColor:"#090D0B",paddingTop:58},
  top:{paddingHorizontal:20,paddingBottom:24,flexDirection:"row",justifyContent:"space-between",alignItems:"center"},
  eyebrow:{fontSize:9,letterSpacing:1.8,color:MUTED,fontWeight:"700"},
  brand:{fontSize:25,fontWeight:"900",color:"#F4F8F5",letterSpacing:1.2,marginTop:4},
  avatar:{height:42,width:42,borderRadius:14,backgroundColor:"#14231A",alignItems:"center",justifyContent:"center",borderWidth:1,borderColor:"#244A32"},
  greeting:{fontSize:25,fontWeight:"800",color:"#F4F8F5",paddingHorizontal:20,marginBottom:5},
  muted:{fontSize:12,color:MUTED,paddingHorizontal:0,lineHeight:19},
  row:{flexDirection:"row",gap:10,paddingHorizontal:16,marginTop:18},
  card:{backgroundColor:"#111915",borderColor:"#1D2A22",borderWidth:1,borderRadius:17,padding:16,marginHorizontal:16,marginTop:12,flex:1},
  metric:{fontSize:24,color:"#F4F8F5",fontWeight:"800",marginTop:7},
  unit:{fontSize:11,color:MUTED,fontWeight:"500"},
  between:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",gap:8},
  cardTitle:{fontSize:15,fontWeight:"700",color:"#F4F8F5"},
  tag:{fontSize:9,color:GREEN,letterSpacing:1,fontWeight:"800"},
  workout:{fontSize:19,color:"#F4F8F5",fontWeight:"800",marginTop:14,marginBottom:3},
  primary:{backgroundColor:GREEN,borderRadius:12,padding:14,marginTop:16,flexDirection:"row",justifyContent:"center",alignItems:"center",gap:8},
  primaryText:{fontWeight:"800",color:"#06110A",fontSize:13},
  week:{flexDirection:"row",justifyContent:"space-between",marginTop:18},
  day:{alignItems:"center",gap:7},
  dot:{height:34,width:34,borderRadius:12,backgroundColor:"#202B24",alignItems:"center",justifyContent:"center"},
  dotActive:{backgroundColor:GREEN},
  dayLetter:{color:"#C5D0C8",fontWeight:"800"},
  dayLabel:{fontSize:9,color:MUTED},
  body:{fontSize:13,color:"#E5EEE8",fontWeight:"600"},
  track:{height:7,backgroundColor:"#25332A",borderRadius:9,overflow:"hidden",marginTop:7},
  fill:{height:7,backgroundColor:GREEN,borderRadius:9},
  link:{color:GREEN,fontSize:12,fontWeight:"700",marginTop:17},
  nav:{position:"absolute",bottom:0,left:0,right:0,backgroundColor:"#0E1511",borderTopWidth:1,borderTopColor:"#1D2A22",paddingTop:10,paddingBottom:25,flexDirection:"row",justifyContent:"space-around"},
  navItem:{alignItems:"center",gap:4,flex:1},
  navText:{fontSize:9,color:MUTED,fontWeight:"600"}
});