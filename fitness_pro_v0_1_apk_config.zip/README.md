# Fitness Pro — primera versión

Aplicación móvil multiplataforma con Expo + React Native. Incluye una primera interfaz navegable con tema oscuro/verde y la estructura inicial de base de datos privada en Supabase.

## Requisitos
- Node.js LTS
- npm
- Expo Go en el móvil para previsualizar (o simulador Android/iOS)

## Ejecutar
```bash
npm install
npx expo start
```
Escanea el QR con Expo Go. Para compilar instaladores nativos más adelante, configurar EAS Build.

## Configurar Supabase
1. Crea un proyecto Supabase.
2. Ejecuta `supabase/schema.sql` en el SQL Editor.
3. Copia `.env.example` a `.env` y añade la URL y la clave anon/public del proyecto.
4. No incluyas nunca la `service_role` key en la aplicación móvil.

## Privacidad y permisos
- Las rutinas, sesiones, series y estimaciones están aisladas por `user_id` mediante Row Level Security.
- El administrador de invitaciones no obtiene permisos para leer entrenamientos de otros usuarios.
- Crear y canjear invitaciones debe hacerse mediante una Edge Function/servidor de confianza; el cliente nunca debe recibir la clave service role.

## Qué incluye esta primera entrega
- Navegación entre Inicio, Rutinas, Entrenar, Progreso, Fatiga y Perfil.
- Tema oscuro con acentos verdes.
- Datos de ejemplo claramente identificados como demostración.
- Esquema SQL inicial para perfiles, ejercicios, rutinas, sesiones, series, estimaciones musculares e invitaciones.

## Pendiente para la siguiente iteración
- Autenticación y flujo real de invitaciones.
- Conexión Supabase desde la app.
- CRUD de rutinas y ejercicios.
- Registro persistente de series y cronómetro.
- Gráficas e historial semanal.
- Anatomía frontal/posterior interactiva y algoritmo de carga muscular validado.
- Sincronización offline y pruebas de seguridad.

Los porcentajes de carga muscular deberán presentarse como estimaciones orientativas, no como medición clínica de recuperación.


## Generar APK Android con EAS
El perfil `preview` está configurado para producir un APK instalable directamente en un dispositivo Android:
```bash
eas build --platform android --profile preview
```
